
//import java.util.Scanner;
import java.net.*;
import java.io.*;

public class GroceryGoServer {

	/* UDP datagram packets and sockets used to send / receive. */
	private static ServerSocket receiveSocket;
	// private DatagramSocket sendPacket;

	private int threadNumber;
	private ClientConnection clientConnection;
	/// private boolean running;

	private GroceryGoServer() {

	}

	public void receiveRequest() {
		System.out.println("Server Started.");
		threadNumber = 0;
		try {
			receiveSocket = new ServerSocket(60800);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		while (true) {

			Socket connectionSocket = null;
			try {
				System.out.println("waiting");
				connectionSocket = receiveSocket.accept();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}


			threadNumber++;
			clientConnection = new ClientConnection(connectionSocket, threadNumber);
			clientConnection.start();

		}
	}


	public static void main(String args[]) throws IOException {
		GroceryGoServer server = new GroceryGoServer();
		server.receiveRequest();

	}

}