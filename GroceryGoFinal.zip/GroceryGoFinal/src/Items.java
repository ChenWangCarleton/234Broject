public class Items{

	public String category="";
	public String price="";
	public String description="";
	public String name="";
	public String store="";
//	public int productID;
	public String brand="";
	public String image="";
	public String toString() {
		//return "Product ID:"+productID+"   category: "+category+"  brand: "+brand+"  name: "+name+"  description: "+description+"    price: "+price;
		return "   category: "+category+"  name: "+name+"  description: "+description+"    price: "+price+"     brand:"+brand+"   store:"+store;
	}
}